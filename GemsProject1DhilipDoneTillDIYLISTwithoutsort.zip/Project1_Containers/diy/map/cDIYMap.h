﻿#pragma once

class cDIYMap
{
public:
	
};
